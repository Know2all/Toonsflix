$('#removeItem-btn').on('click',function(e){
    var id = $(this).data('id');
    var tbl = $(this).data('table');
    console.log(id);
});